# Restaurar la versión con el globo primero

Esta copia conserva el proyecto tal como estaba cuando Hear the planet abría directamente el globo interactivo, con Explore the collection a la izquierda de Choose a place y la colección debajo.

Para recuperar solo esta pantalla en una versión más reciente, vuelve a montar WorldMap antes de la colección usando el App.tsx de esta copia como referencia. Los archivos del globo, su geometría, datos y estilos están incluidos. La intro One planet. Nine questions es independiente.

Para abrir esta copia completa, extrae el ZIP en otra carpeta, ejecuta npm ci y npm run dev.
