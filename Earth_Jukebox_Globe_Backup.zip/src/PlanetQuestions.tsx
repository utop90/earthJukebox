import { useEffect, useRef, useState, type CSSProperties } from 'react';
import type { Language } from './LanguageSwitch';
import './planet-questions.css';

const tracks = [
  ['Sea level change', 'Nivel del mar', 'How much has the ocean risen?', '¿Cuánto ha subido el nivel del mar?', 'Global mean sea level · 1993–2024', 'Nivel medio global · 1993–2024', '≈', '#498ab2', 'a000000/a005500/a005516/', 'seaLevelRise_2024_English.mp4', 'seaLevelRise_2024.jpg'],
  ['Air quality', 'Calidad del aire', 'Where do fine particles travel?', '¿Adónde viajan las partículas finas?', 'Modelled surface PM₂.₅', 'PM₂.₅ en superficie según el modelo', '≋', '#7e968e', 'a000000/a005100/a005151/', 'MC01_stage4_GMAO_pm25_2048x1024_en.mp4', 'MC01_stage4_GMAO_pm25_2048x1024_en.00001_searchweb.png'],
  ['Biodiversity', 'Biodiversidad', 'How does vegetation change across habitats?', '¿Cómo cambia la vegetación entre hábitats?', 'Global vegetation greenness · Terra MODIS', 'Verdor de la vegetación mundial · Terra MODIS', '❋', '#5a9269', 'a030000/a031000/a031053/', 'CMG_0_05_Deg_Monthly_NDVI_720p.webm', 'CMG_0_05_Deg_16_days_NDVI_searchweb.png'],
  ['Wildfires', 'Incendios forestales', 'Where and when does fire flare up?', '¿Dónde y cuándo se detecta fuego?', 'Global active fire detections · Since 2024', 'Focos de fuego activos en el mundo · Desde 2024', '♨', '#d26a44', 'a000000/a005100/a005113/', 'fires_frp_VIIRS_2048p30.mp4', 'fires_frp_VIIRS.892_searchweb.png'],
  ['Greenhouse gases', 'Gases de efecto invernadero', 'How has atmospheric CO₂ changed?', '¿Cómo ha cambiado el CO₂ atmosférico?', 'Global atmospheric CO₂ · 2002–2022', 'CO₂ atmosférico global · 2002–2022', 'CO₂', '#ad79b0', 'a000000/a005000/a005024/', 'co2airs_60South_1920x1080p30.webm', 'co2airs_60South_1920x108030p.0794_print.jpg'],
  ['Energy', 'Energía', 'Where is the world getting brighter at night?', '¿Dónde se ilumina más el mundo de noche?', 'Nighttime lights · 2012–2023', 'Luces nocturnas · 2012–2023', '✦', '#d0a453', 'a000000/a005300/a005313/', 'nightlights_flat_series_and_change_wZooms_13_EIC_2160p30_h265.mp4', 'nightlights_flat_series_and_change_wZooms_13_EIC.02599_searchweb.png'],
  ['Disasters', 'Desastres', 'Where do earthquakes cluster?', '¿Dónde se concentran los terremotos?', 'Cumulative global earthquakes · 1980–1995', 'Terremotos acumulados en el mundo · 1980–1995', '⌁', '#c4816f', 'a000000/a002800/a002893/', 'eqmollweide_1080p30.mp4', 'earthquakes_pre.jpg'],
  ['Water resources', 'Recursos hídricos', 'Where do groundwater conditions change?', '¿Dónde cambian las condiciones del agua subterránea?', 'Global shallow groundwater', 'Agua subterránea poco profunda a escala mundial', '◈', '#4c9fb5', 'a030000/a031100/a031178/', 'GRACE_GLOBAL_7D_GWS_030_1080p10.webm', 'GRACE_GLOBAL_7D_GWS_030_20251124.png'],
  ['Agriculture', 'Agricultura', 'When do croplands green up?', '¿Cuándo reverdecen las zonas de cultivo?', 'Seasonal vegetation greenness · Terra MODIS', 'Verdor estacional de la vegetación · Terra MODIS', '✿', '#a0a65b', 'a030000/a031000/a031053/', 'CMG_0_05_Deg_Monthly_NDVI_720p.webm', 'CMG_0_05_Deg_16_days_NDVI_searchweb.png'],
].map(([area, areaEs, question, questionEs, detail, detailEs, symbol, color, folder, file, image]) => {
  const base = 'https://svs.gsfc.nasa.gov/vis/' + folder;
  return { area, areaEs, question, questionEs, detail, detailEs, symbol, color, video: base + file, poster: image ? base + image : undefined };
});

export default function PlanetQuestions({ language }: { language: Language }) {
  const es = language === 'es';
  const [intro, setIntro] = useState(() => !window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const [chosen, setChosen] = useState<typeof tracks[number] | null>(null);
  const [sound, setSound] = useState<'idle' | 'loading' | 'playing' | 'error'>('idle');
  const [videoFailed, setVideoFailed] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null);
  const stop = useRef<(() => void) | null>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => setIntro(false), 5700);
    return () => window.clearTimeout(timer);
  }, []);
  useEffect(() => () => stop.current?.(), []);

  function toggleSound(url: string) {
    if (stop.current) {
      stop.current();
      stop.current = null;
      setSound('idle');
      return;
    }
    const controller = new AbortController();
    let context: AudioContext;
    try {
      context = new AudioContext();
    } catch {
      setSound('error');
      return;
    }
    const cancel = () => {
      window.clearTimeout(timer);
      controller.abort();
      if (context.state !== 'closed') void context.close();
    };
    const timer = window.setTimeout(() => {
      cancel();
      stop.current = null;
      setSound('error');
    }, 20000);
    stop.current = cancel;
    setSound('loading');
    void Promise.all([context.resume(), import('./frameSound')])
      .then(([, module]) => module.playFrameSound(url, context, controller.signal, () => setSound('playing')))
      .then(() => finish('idle'), () => finish('error'));

    function finish(result: 'idle' | 'error') {
      if (controller.signal.aborted) return;
      cancel();
      stop.current = null;
      setSound(result);
    }
  }

  return <section className={`planet-questions${intro ? ' planet-intro-playing' : ''}`} aria-labelledby="planet-questions-title">
    <div className="planet-heading">
      <h1 id="planet-questions-title">{es ? 'Un planeta. Nueve preguntas' : 'One planet. Nine questions'}</h1>
      {intro && <button className="planet-skip" onClick={() => setIntro(false)}>{es ? 'Saltar intro' : 'Skip intro'}</button>}
    </div>
    <div className="planet-layout">
      <div className="planet-scene" aria-hidden="true">
        <div className="planet-jukebox"><div className="planet-record" /><div className="planet-speaker" /></div>
        <div className="planet-earth" style={{ '--planet-outline': `url(${import.meta.env.BASE_URL}world-outline.svg)` } as CSSProperties}>
          <span className="planet-half planet-half-left" />
          <span className="planet-core" />
          <span className="planet-half planet-half-right" />
        </div>
      </div>
      <div className="planet-tracks">
        {tracks.map((track, index) => <button key={track.area} type="button" className="planet-track" aria-haspopup="dialog"
          style={{ '--track-color': track.color, '--delay': `${2.5 + Math.floor(index / 3) * .64 + index % 3 * .12}s`, '--origin-y': `${(1 - Math.floor(index / 3)) * 105}%` } as CSSProperties}
          onClick={() => {
            setIntro(false);
            setVideoFailed(false);
            setChosen(track);
            dialog.current?.showModal();
          }}>
          <span className="planet-track-art" aria-hidden="true">
            <span>{track.symbol}</span>
            {track.poster && <img src={track.poster} alt="" decoding="async" onError={event => { event.currentTarget.hidden = true; }} />}
          </span>
          <span className="planet-track-copy">
            <span className="planet-area">{es ? track.areaEs : track.area}</span>
            <span className="planet-question">{es ? track.questionEs : track.question}</span>
          </span>
          <span className="planet-track-play" aria-hidden="true">▶</span>
        </button>)}
      </div>
    </div>
    <dialog ref={dialog} className="world-audio planet-track-dialog" aria-labelledby="planet-video-title" onClose={() => {
      stop.current?.();
      stop.current = null;
      setChosen(null);
      setSound('idle');
    }}>
      {chosen && <>
        <button type="button" className="world-close" aria-label={es ? 'Cerrar vídeo' : 'Close video'} onClick={() => dialog.current?.close()}>×</button>
        <h2 id="planet-video-title">{es ? chosen.questionEs : chosen.question}</h2>
        {videoFailed ? <p role="alert">{es ? 'El vídeo no está disponible en este navegador.' : 'This video is unavailable in this browser.'}</p> :
          <video key={chosen.video} className="world-video" controls autoPlay muted playsInline poster={chosen.poster}
            src={es && chosen.area === 'Sea level change' ? chosen.video.replace('_English', '_Spanish') : chosen.video}
            aria-label={es ? chosen.detailEs : chosen.detail} onError={() => setVideoFailed(true)} />}
        <section className="world-sound-player" aria-labelledby="planet-sound-title">
          <h3 id="planet-sound-title">{es ? chosen.detailEs : chosen.detail}</h3>
          <button type="button" className="world-listen" onClick={() => toggleSound(chosen.video)}>
            {sound === 'loading' || sound === 'playing' ? (es ? 'Detener sonido' : 'Stop sound') : (es ? 'Escuchar los fotogramas' : 'Listen to the frames')}
          </button>
          <p>{es ? 'Las zonas más luminosas de cada fotograma producen notas más agudas.' : 'Brighter areas of each frame produce higher notes.'}</p>
          {sound === 'loading' && <p role="status">{es ? 'Preparando el sonido…' : 'Preparing sound…'}</p>}
          {sound === 'error' && <p role="alert">{es ? 'No se pudo generar sonido a partir de este vídeo.' : 'Sound could not be generated from this video.'}</p>}
        </section>
      </>}
    </dialog>
  </section>;
}
