# Earth Jukebox — One planet. Nine questions

Decisión del proyecto: la intro queda desactivada temporalmente. Hear the planet abre directamente el globo interactivo y la colección permanece debajo. Restaurar solo cuando el usuario lo pida.

La intro muestra una jukebox en verde, un globo que sale y se abre, y nueve preguntas que aparecen a su derecha. Cada pregunta abre su vídeo mundial con controles de sonificación. Incluye Saltar intro y respeta la preferencia de movimiento reducido.

Para restaurar, usa los archivos de src y public incluidos si faltan. En src/App.tsx importa PlanetQuestions desde './PlanetQuestions' y añade <PlanetQuestions language={language} /> inmediatamente antes de WorldMap. Conserva WorldMap y la colección.
