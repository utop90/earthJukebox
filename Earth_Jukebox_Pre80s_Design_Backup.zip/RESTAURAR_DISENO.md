Extrae la copia en otra carpeta. Ejecuta npm ci y npm run dev para recuperar la versión anterior al rediseño ochentero, con One planet. Nine questions activa.
